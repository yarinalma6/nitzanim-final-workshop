# Status-Page v2.0

## v2.0.17 (FUTURE)

---

## v2.0.16 (2022-12-19)
* Increase Incident and Maintenance Update Text Length

---

## v2.0.15 (2022-12-06)

### Bug fixes
* Incident Update edit text box

---

## v2.0.14 (2022-11-12)

### Bug fixes
* Fix redis connection within collectstatic command

---

## v2.0.13 (2022-11-12)

### Bug fixes
* Fix redis connection within collectstatic command

---

## v2.0.12 (2022-11-12)

### Bug fixes
* Add missing Media folder

---

## v2.0.11 (2022-11-04)

### Bug fixes
* Add missing E-Mail Templates for Notifications

---

## v2.0.10 (2022-11-04)

### Bug fixes
* Fix select Styles

---

## v2.0.9 (2022-11-04)

### Bug fixes
* Add missing Plugin Views

---

## v2.0.8 (2022-11-04)

### Bug fixes
* Make Component Group collapse choices actually work
* Make Metric collapse choices actually work
* Make Component Links and Descriptions work

---

## v2.0.7 (2022-11-04)

### Bug fixes
* Fix Assets

---

## v2.0.6 (2022-11-03)

### Bug fixes
* Fix Default files and requirements

---

## v2.0.5 (2022-11-03)

### Bug fixes
* Set Python requirement to 3.10

---

## v2.0.4 (2022-11-03)

### Bug fixes
* Fix Database Settings

---

## v2.0.3 (2022-11-03)

### Bug fixes
* Fix Settings

---

## v2.0.2 (2022-11-03)

### Bug fixes
* Fix Database Settings

---

## v2.0.1 (2022-11-03)

### Enhancements
* Add Missing Template parts from Dynamic Config

---

## v2.0.0 (2022-11-03)

### Enhancements
* Rewrite of Status-Page in python, with django

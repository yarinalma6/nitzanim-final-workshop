![Status-Page](https://cdn.herrtxbias.net/status-page/logo_gray/logo.svg "Status-Page logo"){style="height: 75px; margin-bottom: 3rem"}

## Getting Started

* Check out the [installation guide](./installation/index.md) to get your deployment up and running
* Or the [Docker image](https://github.com/status-page/status-page-docker) (coming soon...)

import Alpine from 'alpinejs';

export function initStart(): void {
  Alpine.start();
}

# Prefix for nested serializers
NESTED_SERIALIZER_PREFIX = 'Nested'

# Max results per object type
SEARCH_MAX_RESULTS = 15

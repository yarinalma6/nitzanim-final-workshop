from extras.plugins import PluginMenuItem

menu_items = (
    PluginMenuItem(
        link='plugins:sp_external_status_providers:externalstatuspage_list',
        link_text='Pages',
    ),
    PluginMenuItem(
        link='plugins:sp_external_status_providers:externalstatuscomponent_list',
        link_text='Components',
    ),
)
